# A3-M4 pgvector · Qdrant 실습 폴더

## 1. 서버 띄우기 (Docker)
```bash
docker run -d --name pgvector -e POSTGRES_PASSWORD=postgres -p 5432:5432 pgvector/pgvector:pg17
# (선택) docker run -d --name qdrant -p 6333:6333 -v ./qdrant_storage:/qdrant/storage qdrant/qdrant
```
접속 주소가 다르면 환경변수 `PG_DSN`을 지정합니다. 예: `postgresql://postgres:postgres@localhost:5432/postgres`

## 2. 패키지
```bash
pip install -r requirements.txt
```
노트북은 01 → 04 순서로 실행합니다. Qdrant 노트북은 서버 없이 `qdrant_db/` 폴더 모드로 실행됩니다.
