# Linux Process Check Agent

이 프로젝트는 Ubuntu 서버의 프로세스/PID 상태를 확인하고 HTML 보고서를 만드는 실습이다.

## 규칙
- 조회 명령(`ps`, `top`, `pgrep`, `pidof`)은 실행 가능하다.
- 시스템 상태를 변경하는 명령은 자동 실행하지 않는다.
- `kill`, `killall`, 서비스 중지/재시작은 반드시 사용자 승인을 먼저 받는다.
- `report_template.html`의 디자인/구조는 임의로 변경하지 않는다.
- 보고서는 `process_report.py`를 사용해 `report.html`로 생성한다.
- `htop`이 없으면 임의 설치하지 않는다.
- Gmail 기능이 없으면 전송 성공을 가장하지 않는다.

## 기본 흐름
ps 확인 → PID/CPU/MEM 분석 → 필요 시 top/htop → Python 실행 → report.html 확인 → Gmail 보고
