from pathlib import Path
from datetime import datetime
import subprocess, socket, html

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT).strip()

def safe(cmd):
    try: return sh(cmd)
    except Exception as e: return f"조회 실패: {e}"

count = safe("ps -e --no-headers | wc -l")
cpu = safe("ps -eo pid,user,%cpu,%mem,comm --sort=-%cpu | head -n 6")
mem = safe("ps -eo pid,user,%cpu,%mem,comm --sort=-%mem | head -n 6")
# 수업용 단순 기준: 가장 높은 CPU 프로세스를 관찰 대상으로 표시한다.
line = safe("ps -eo pid=,%cpu=,%mem=,comm= --sort=-%cpu | head -n 1").split()
target_pid = line[0] if line else "없음"
cpu_value = float(line[1]) if len(line) > 1 else 0
status = "주의" if cpu_value >= 80 else "정상"
reason = f"CPU 상위 프로세스의 현재 CPU 사용률은 {cpu_value}%입니다. 단일 시점 값만으로 장애를 확정하지 않습니다."
action = "top/htop으로 추이를 관찰하고 필요하면 해당 PID를 상세 조회하세요. 프로세스 종료는 관리자 승인 후 수행하세요."

template = Path("report_template.html").read_text(encoding="utf-8")
values = {
    "CHECK_TIME": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "HOSTNAME": socket.gethostname(), "PROCESS_COUNT": count,
    "CPU_TOP": cpu, "MEM_TOP": mem, "TARGET_PID": target_pid,
    "STATUS": status, "REASON": reason, "ACTION": action,
}
for key, value in values.items():
    template = template.replace("{{"+key+"}}", html.escape(str(value)))
Path("report.html").write_text(template, encoding="utf-8")
print("report.html 생성 완료")
