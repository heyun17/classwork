#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p data logs
python3 collector.py
exec python3 server.py --host 0.0.0.0 --port "${PS_MONITOR_PORT:-8000}"
