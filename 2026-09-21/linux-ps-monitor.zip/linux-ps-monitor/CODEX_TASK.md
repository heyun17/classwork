# Codex 작업 지시서 - Linux PS 5분 자원 모니터

## 목표

Linux에서 `ps aux` 자원 정보를 5분마다 수집하고 하나의 로그 파일에 누적한다. 첨부 기반 HTML의 **왼쪽 제어 패널 / 오른쪽 보고서 패널 레이아웃을 유지**하면서, 수동 붙여넣기가 아니라 누적 로그를 자동으로 읽어 최신 현황과 이력을 표시한다.

## 현재 구현

- `collector.py`
  - `ps aux` 실행
  - 프로세스별 USER/PID/%CPU/%MEM/RSS/COMMAND 파싱
  - 한 번의 수집 결과를 `data/ps_log.jsonl`에 JSON 한 줄로 append
- `setup_cron.sh`
  - collector를 `*/5 * * * *`로 등록
  - stdout/stderr는 `logs/cron.log`에 append
- `server.py`
  - `/` -> `index.html`
  - `/api/latest` -> 최신 snapshot 전체
  - `/api/history?limit=N` -> 차트용 요약 이력
  - `POST /api/collect` -> 수동 즉시 1회 수집
- `index.html`
  - 좌측: API 상태, 마지막 수집 시각, Top N, CPU/MEM 정렬, 이력 범위, 최신 ps 요약
  - 우측: 최신 요약 카드, 5분 단위 이력 차트, 상위 프로세스 표

## 반드시 유지할 조건

1. 좌/우 레이아웃을 없애지 않는다.
2. 로그 파일은 기본적으로 `data/ps_log.jsonl` 하나를 사용한다.
3. cron 주기는 5분이다.
4. 초보 Linux 수업용이므로 코드 가독성을 우선한다.
5. 별도 요청이 없으면 Flask/FastAPI/DB를 추가하지 않는다.
6. `ps` 기반 수집이라는 과제 목적을 유지한다.
7. 기존 기능을 수정할 때 `README.md`의 실행 방법도 함께 갱신한다.
8. `AGENTS.md`의 규칙을 먼저 읽고 따른다.

## 개선 작업 시 우선순위

1. 수집 실패/깨진 JSON 줄에 대한 내구성
2. 로그가 커졌을 때의 읽기 성능
3. UI 표시 오류 및 빈 데이터 처리
4. cron 중복 등록 방지
5. 교육용 설명/주석 유지

## 완료 검증

```bash
python3 -m py_compile collector.py server.py
python3 collector.py
wc -l data/ps_log.jsonl
./setup_cron.sh
crontab -l
python3 server.py --host 127.0.0.1 --port 8000
```

다른 셸:

```bash
curl -f http://127.0.0.1:8000/api/health
curl -f http://127.0.0.1:8000/api/latest
curl -f 'http://127.0.0.1:8000/api/history?limit=3'
```

브라우저에서는 좌측/우측 레이아웃, 최신 값, 이력 차트, Top 프로세스 표가 모두 갱신되는지 확인한다.
