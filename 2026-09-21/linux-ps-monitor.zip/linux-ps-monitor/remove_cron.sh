#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
TMP_FILE="$(mktemp)"
trap 'rm -f "$TMP_FILE"' EXIT
crontab -l 2>/dev/null | grep -Fv "$BASE_DIR/collector.py" > "$TMP_FILE" || true
crontab "$TMP_FILE"
echo "Removed cron entries containing: $BASE_DIR/collector.py"
