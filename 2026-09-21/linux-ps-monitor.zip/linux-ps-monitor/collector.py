#!/usr/bin/env python3
"""Collect Linux process resource usage with `ps aux` and append one JSONL snapshot."""

from __future__ import annotations

import fcntl
import json
import os
import socket
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("PS_MONITOR_DATA_DIR", BASE_DIR / "data"))
LOG_FILE = DATA_DIR / "ps_log.jsonl"


def parse_ps_aux(text: str) -> list[dict]:
    processes: list[dict] = []
    lines = text.splitlines()
    if not lines:
        return processes

    for line in lines[1:]:
        parts = line.split(None, 10)
        if len(parts) < 11:
            continue
        user, pid, cpu, mem, vsz, rss, tty, stat, start, cputime, command = parts
        try:
            processes.append(
                {
                    "user": user,
                    "pid": int(pid),
                    "cpu": float(cpu),
                    "mem": float(mem),
                    "vsz_kb": int(vsz),
                    "rss_kb": int(rss),
                    "tty": tty,
                    "stat": stat,
                    "start": start,
                    "time": cputime,
                    "command": command,
                }
            )
        except ValueError:
            continue
    return processes


def collect_snapshot() -> dict:
    result = subprocess.run(
        ["ps", "aux"],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    processes = parse_ps_aux(result.stdout)

    now = datetime.now().astimezone()
    return {
        "timestamp": now.isoformat(timespec="seconds"),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "hostname": socket.gethostname(),
        "process_count": len(processes),
        "user_count": len({p["user"] for p in processes}),
        "cpu_sum": round(sum(p["cpu"] for p in processes), 1),
        "mem_sum": round(sum(p["mem"] for p in processes), 1),
        "loadavg": [round(x, 2) for x in os.getloadavg()],
        "processes": processes,
    }


def append_snapshot(snapshot: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    line = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")) + "\n"
    with LOG_FILE.open("a", encoding="utf-8") as fp:
        fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
        fp.write(line)
        fp.flush()
        os.fsync(fp.fileno())
        fcntl.flock(fp.fileno(), fcntl.LOCK_UN)


def main() -> int:
    try:
        snapshot = collect_snapshot()
        append_snapshot(snapshot)
    except Exception as exc:
        print(f"collector error: {exc}", file=sys.stderr)
        return 1

    print(
        f"[{snapshot['timestamp']}] host={snapshot['hostname']} "
        f"processes={snapshot['process_count']} cpu_sum={snapshot['cpu_sum']}% "
        f"mem_sum={snapshot['mem_sum']}% -> {LOG_FILE}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
