#!/usr/bin/env python3
"""Serve the dashboard and JSON API for Linux ps snapshots."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("PS_MONITOR_DATA_DIR", BASE_DIR / "data"))
LOG_FILE = DATA_DIR / "ps_log.jsonl"
INDEX_FILE = BASE_DIR / "index.html"
COLLECTOR = BASE_DIR / "collector.py"
MAX_HISTORY = 2016  # 7 days at 5-minute intervals


def read_records(limit: int) -> list[dict]:
    if not LOG_FILE.exists():
        return []
    limit = max(1, min(limit, MAX_HISTORY))
    rows: deque[str] = deque(maxlen=limit)
    with LOG_FILE.open("r", encoding="utf-8", errors="replace") as fp:
        for line in fp:
            if line.strip():
                rows.append(line)

    records: list[dict] = []
    for line in rows:
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


def public_summary(record: dict) -> dict:
    return {
        "timestamp": record.get("timestamp"),
        "hostname": record.get("hostname"),
        "process_count": record.get("process_count", 0),
        "user_count": record.get("user_count", 0),
        "cpu_sum": record.get("cpu_sum", 0),
        "mem_sum": record.get("mem_sum", 0),
        "loadavg": record.get("loadavg", []),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "LinuxPsMonitor/1.0"

    def log_message(self, fmt: str, *args) -> None:
        sys.stdout.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))

    def send_json(self, payload, status=HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            if not INDEX_FILE.exists():
                self.send_error(HTTPStatus.NOT_FOUND, "index.html not found")
                return
            body = INDEX_FILE.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        if path == "/api/health":
            self.send_json({"ok": True, "log_file": str(LOG_FILE), "log_exists": LOG_FILE.exists()})
            return

        if path == "/api/latest":
            rows = read_records(1)
            self.send_json(rows[-1] if rows else None)
            return

        if path == "/api/history":
            try:
                limit = int(query.get("limit", ["288"])[0])
            except ValueError:
                limit = 288
            rows = read_records(limit)
            self.send_json([public_summary(row) for row in rows])
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Not found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/collect":
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return

        try:
            proc = subprocess.run(
                [sys.executable, str(COLLECTOR)],
                cwd=BASE_DIR,
                capture_output=True,
                text=True,
                timeout=20,
            )
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)
            return

        if proc.returncode != 0:
            self.send_json(
                {"ok": False, "error": proc.stderr.strip() or "collector failed"},
                HTTPStatus.INTERNAL_SERVER_ERROR,
            )
            return
        self.send_json({"ok": True, "message": proc.stdout.strip()})


def main() -> int:
    parser = argparse.ArgumentParser(description="Linux ps monitor web server")
    parser.add_argument("--host", default=os.environ.get("PS_MONITOR_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PS_MONITOR_PORT", "8000")))
    args = parser.parse_args()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Linux PS monitor: http://{args.host}:{args.port}")
    print(f"Data log: {LOG_FILE}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
