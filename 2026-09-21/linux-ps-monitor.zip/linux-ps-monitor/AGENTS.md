# AGENTS.md

## Project purpose

This repository is a small Linux training project that samples `ps aux` every five minutes, appends snapshots to a JSONL file, and shows the collected data in a browser dashboard.

## Non-negotiable requirements

1. Keep the UI as a two-column layout:
   - left: controls/status/raw summary
   - right: report/dashboard
2. Keep cron collection at exactly every 5 minutes unless the user explicitly changes the requirement.
3. Collection must append to a single log file: `data/ps_log.jsonl`.
4. Do not replace JSONL with a database unless the user explicitly asks.
5. Prefer Python standard library. Do not add Flask/FastAPI unless requested.
6. The dashboard must work through `server.py`; do not assume `file://` can fetch local logs.
7. Keep the project beginner-readable. Avoid unnecessary abstractions.
8. Preserve Korean labels in the dashboard and README unless asked otherwise.

## File responsibilities

- `collector.py`: run `ps aux`, parse it, append exactly one snapshot.
- `server.py`: serve `index.html` and read-only log APIs; `/api/collect` may trigger one manual collection.
- `index.html`: presentation only; never write directly to the JSONL file.
- `setup_cron.sh`: idempotently install the project's 5-minute cron entry.
- `remove_cron.sh`: remove only this project's collector cron entry.
- `run.sh`: convenient foreground start for classroom/demo use.

## Data contract

Each JSONL row should keep these fields unless there is a deliberate migration:

```json
{
  "timestamp": "ISO-8601 local time",
  "timestamp_utc": "ISO-8601 UTC time",
  "hostname": "string",
  "process_count": 0,
  "user_count": 0,
  "cpu_sum": 0.0,
  "mem_sum": 0.0,
  "loadavg": [0.0, 0.0, 0.0],
  "processes": []
}
```

Process objects include at least `user`, `pid`, `cpu`, `mem`, and `command`.

## Validation before finishing changes

Run:

```bash
python3 -m py_compile collector.py server.py
python3 collector.py
python3 server.py --host 127.0.0.1 --port 8000
```

Then verify in another shell:

```bash
curl -f http://127.0.0.1:8000/api/health
curl -f http://127.0.0.1:8000/api/latest
curl -f 'http://127.0.0.1:8000/api/history?limit=3'
```

Do not commit generated monitoring data unless the user asks for sample data.
