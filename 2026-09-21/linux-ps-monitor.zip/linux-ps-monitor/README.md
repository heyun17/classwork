# Linux PS Monitor

Linux의 `ps aux` 결과를 **5분마다 cron으로 수집해 JSONL 로그에 계속 추가**하고, Python 웹 서버가 그 로그를 읽어 브라우저 대시보드에 반영하는 실습 프로젝트입니다.

기존 HTML의 핵심인 **왼쪽 제어 패널 / 오른쪽 보고서 패널** 구조는 유지했습니다. 수동 붙여넣기 대신 최신 로그를 자동으로 읽습니다.

## 1. 구성

```text
linux-ps-monitor/
├── collector.py       # ps aux 실행 -> data/ps_log.jsonl에 1줄 추가
├── server.py          # HTML + /api/latest + /api/history 제공
├── index.html         # 대시보드
├── run.sh             # 1회 수집 후 웹 서버 실행
├── setup_cron.sh      # 5분 cron 등록
├── remove_cron.sh     # 이 프로젝트 cron 제거
├── CODEX_TASK.md      # Codex에 넘길 작업 설명
├── AGENTS.md          # Codex 작업 규칙
├── data/
└── logs/
```

## 2. Windows -> Multipass Ubuntu로 보내기

Multipass의 `transfer`는 폴더 전체 재귀 전송용으로 쓰기 불편하므로, **ZIP 파일 하나를 전송한 뒤 Ubuntu에서 압축을 푸는 방식**이 가장 단순합니다.

Windows PowerShell에서, 다운로드한 `linux-ps-monitor.zip`이 있는 폴더로 이동한 뒤:

```powershell
multipass transfer .\linux-ps-monitor.zip myUbuntu:/home/ubuntu/linux-ps-monitor.zip
multipass shell myUbuntu
```

이제 아래부터는 Ubuntu(Multipass) 터미널에서 실행합니다.

```bash
cd ~
sudo apt update
sudo apt install -y unzip cron
unzip -o linux-ps-monitor.zip
cd linux-ps-monitor
chmod +x run.sh setup_cron.sh remove_cron.sh collector.py server.py
```

> VM 이름이 `myUbuntu`가 아니라면 위 명령의 `myUbuntu`를 실제 인스턴스 이름으로 바꾸세요. Windows에서 `multipass list`로 확인할 수 있습니다.

## 3. 먼저 수동 수집 테스트

```bash
cd ~/linux-ps-monitor
python3 collector.py
```

정상 예시:

```text
[2026-09-21T15:00:00+09:00] host=myUbuntu processes=... cpu_sum=...% mem_sum=...% -> .../data/ps_log.jsonl
```

로그 확인:

```bash
tail -n 1 data/ps_log.jsonl
```

## 4. 5분마다 자동 수집하도록 cron 등록

```bash
cd ~/linux-ps-monitor
./setup_cron.sh
```

등록 확인:

```bash
crontab -l
```

다음 형태의 한 줄이 보이면 됩니다.

```text
*/5 * * * * cd /home/ubuntu/linux-ps-monitor && /usr/bin/python3 /home/ubuntu/linux-ps-monitor/collector.py >> /home/ubuntu/linux-ps-monitor/logs/cron.log 2>&1
```

cron 서비스 확인:

```bash
systemctl status cron --no-pager
```

필요하면 시작/활성화:

```bash
sudo systemctl enable --now cron
```

5분 뒤 로그 개수 확인:

```bash
wc -l data/ps_log.jsonl
tail -n 3 data/ps_log.jsonl
```

cron 실행 기록/오류 확인:

```bash
tail -f logs/cron.log
```

## 5. 웹 화면 실행

가장 간단한 방법:

```bash
cd ~/linux-ps-monitor
./run.sh
```

`run.sh`는 시작할 때 한 번 즉시 수집한 뒤 서버를 엽니다.

서버 주소:

```text
http://0.0.0.0:8000
```

Multipass 안에서는 다음으로 테스트할 수 있습니다.

```bash
curl http://127.0.0.1:8000/api/health
curl http://127.0.0.1:8000/api/latest
```

### Windows 크롬에서 열기

Windows PowerShell에서 VM IP 확인:

```powershell
multipass info myUbuntu
```

출력의 `IPv4`가 예를 들어 `172.20.10.5`라면 크롬 주소창에:

```text
http://172.20.10.5:8000
```

를 입력합니다.

## 6. 실행 구조

```text
cron (5분마다)
    |
    v
collector.py
    |
    v
data/ps_log.jsonl  <- 계속 append
    |
    v
server.py  -- /api/latest, /api/history
    |
    v
index.html
    |
    +-- 왼쪽: 수집 상태 / Top N / 정렬 / 최신 ps 요약
    +-- 오른쪽: 최신 요약 / 5분 이력 차트 / 상위 프로세스 표
```

## 7. 로그 형식

`data/ps_log.jsonl`은 **한 줄 = 한 번의 수집 결과**입니다. 주요 필드:

- `timestamp`: 수집 시각
- `hostname`: 호스트명
- `process_count`: 프로세스 수
- `user_count`: 실행 사용자 수
- `cpu_sum`: `ps aux`의 `%CPU` 합계
- `mem_sum`: `ps aux`의 `%MEM` 합계
- `loadavg`: 1/5/15분 load average
- `processes`: 각 프로세스의 USER, PID, CPU, MEM, RSS, COMMAND 등

`%CPU` 합계는 멀티코어 Linux에서 100%를 넘을 수 있습니다. 이 값은 전체 시스템 CPU 사용률이 아니라 **`ps aux`에 표시된 프로세스별 `%CPU`의 합계**입니다.

## 8. 서버만 직접 실행

```bash
python3 server.py --host 0.0.0.0 --port 8000
```

포트를 바꾸려면:

```bash
PS_MONITOR_PORT=8080 ./run.sh
```

## 9. cron 제거

```bash
cd ~/linux-ps-monitor
./remove_cron.sh
crontab -l
```

## 10. 종료

웹 서버는 실행 중인 터미널에서:

```text
Ctrl + C
```

Multipass 셸 종료:

```bash
exit
```

VM 자체를 멈추려면 Windows PowerShell에서:

```powershell
multipass stop myUbuntu
```

## 11. 주의사항

- HTML 파일을 Windows에서 더블클릭(`file://`)하는 방식이 아니라 **반드시 `server.py`를 통해 열어야** API 로그를 읽을 수 있습니다.
- `Chart.js`는 CDN을 사용하므로 차트 표시 시 브라우저 인터넷 연결이 필요합니다. 표와 API 데이터 자체는 Python 표준 라이브러리만으로 동작합니다.
- 이 프로젝트는 교육/로컬 실습용입니다. `server.py`를 공용 인터넷에 그대로 노출하지 마세요.
