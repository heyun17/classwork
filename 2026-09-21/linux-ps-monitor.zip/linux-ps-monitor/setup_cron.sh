#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="$(command -v python3)"
CRON_LOG="$BASE_DIR/logs/cron.log"
mkdir -p "$BASE_DIR/data" "$BASE_DIR/logs"

JOB="*/5 * * * * cd $BASE_DIR && $PYTHON_BIN $BASE_DIR/collector.py >> $CRON_LOG 2>&1"
TMP_FILE="$(mktemp)"
trap 'rm -f "$TMP_FILE"' EXIT

crontab -l 2>/dev/null | grep -Fv "$BASE_DIR/collector.py" > "$TMP_FILE" || true
printf '%s\n' "$JOB" >> "$TMP_FILE"
crontab "$TMP_FILE"

echo "Cron registration complete:"
echo "$JOB"
echo
echo "Check with: crontab -l"
echo "Collector log: $CRON_LOG"
